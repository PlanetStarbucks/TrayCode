export type ContentCredentialsBetaAuth = any; // No Authentication
