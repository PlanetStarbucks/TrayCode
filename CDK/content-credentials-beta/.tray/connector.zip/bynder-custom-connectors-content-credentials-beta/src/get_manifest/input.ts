export type GetManifestInput = {
	url: string;
	mime_type: string;
};
