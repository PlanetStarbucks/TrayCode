export type GetManifestOutput = {
	manifest: string;
};
