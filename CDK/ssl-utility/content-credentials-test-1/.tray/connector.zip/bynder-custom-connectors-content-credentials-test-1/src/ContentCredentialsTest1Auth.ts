export type ContentCredentialsTest1Auth = never; // No Authentication
