export type ReadManifestOutput = {
	manifest: any;
};

// export type Manifest = {
// 	active_manifest: any;
// 	manifests: any;
// 	validation_status: any;
// };
